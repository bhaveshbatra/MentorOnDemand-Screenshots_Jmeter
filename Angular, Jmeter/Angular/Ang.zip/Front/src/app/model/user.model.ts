export class User {

  id: number;

}
