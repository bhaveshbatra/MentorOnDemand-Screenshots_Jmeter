import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-nav',
  templateUrl: './mentor-nav.component.html',
  styleUrls: ['./mentor-nav.component.css']
})
export class MentorNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
