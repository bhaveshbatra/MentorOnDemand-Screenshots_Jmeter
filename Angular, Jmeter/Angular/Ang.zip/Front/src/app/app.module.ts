import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { ListUserComponent } from './user/list-user/list-user.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { EditUserComponent } from './user/edit-user/edit-user.component';
//import {routing} from "./app.routing";
import {ReactiveFormsModule} from "@angular/forms";
import {ApiService} from "./service/api.service";
import {HTTP_INTERCEPTORS, HttpClientModule} from "@angular/common/http";
import {TokenInterceptor} from "./core/interceptor";
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { CustomersListComponent } from './customers-list/customers-list.component';
import { SearchCustomersComponent } from './search-customers/search-customers.component';
import { AppRoutingModule } from './app-routing.module';
//import { HttpClientModule } from '@angular/common/http';
import { UserLoginComponent } from './user-login/user-login.component';
import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { MentorHomeComponent } from './mentor-home/mentor-home.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { MylearningsComponent } from './mylearnings/mylearnings.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorNavComponent } from './mentor-nav/mentor-nav.component';
import { AdminNavComponent } from './admin-nav/admin-nav.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { UserNavComponent } from './user-nav/user-nav.component';
import { AddTechnologyComponent } from './add-technology/add-technology.component';


@NgModule({
  declarations: [
    AppComponent,
    CreateCustomerComponent,
    CustomerDetailsComponent,
    CustomersListComponent,
    SearchCustomersComponent,
    UserLoginComponent,
    NavComponent,
    HomeComponent,
    UserSignupComponent,
    UserHomeComponent,
    MentorHomeComponent,
    AdminHomeComponent,
    MylearningsComponent,
    MentorProfileComponent,
    MentorNavComponent,
    AdminNavComponent,
    MentorSignupComponent,
    UserNavComponent,
    ListUserComponent,
    AddUserComponent,
    EditUserComponent,
    AddTechnologyComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [ApiService, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
