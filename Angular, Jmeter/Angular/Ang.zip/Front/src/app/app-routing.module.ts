import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CustomersListComponent } from './customers-list/customers-list.component';
import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { SearchCustomersComponent } from './search-customers/search-customers.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { HomeComponent } from './home/home.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { MentorHomeComponent } from './mentor-home/mentor-home.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { MylearningsComponent } from './mylearnings/mylearnings.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import {AddUserComponent} from "./user/add-user/add-user.component";
import {ListUserComponent} from "./user/list-user/list-user.component";
import {EditUserComponent} from "./user/edit-user/edit-user.component";

/*const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component:HomeComponent},
    { path: 'customer', component: CustomersListComponent },
    { path: 'add', component: CreateCustomerComponent },
    { path: 'findbyage', component: SearchCustomersComponent },
    { path: 'signin', component:UserLoginComponent},
    { path: 'signup', component:UserSignupComponent},
    { path: 'userHome', component:UserHomeComponent},
    { path: 'signin/userHome', component:UserHomeComponent},
    { path: 'mentorHome', component:MentorHomeComponent},
    { path: 'adminHome', component:AdminHomeComponent},
    { path: 'mylearning', component:MylearningsComponent},
    { path: 'userHome/mentorProfile', component:MentorProfileComponent}

];
*/
const routes: Routes = [
    {
      path:'',redirectTo:'home',pathMatch:'full'
    },
    {
      path:'home',component:HomeComponent,
      children:[
        {
          path:'',redirectTo:'home-dash',pathMatch:'full'
        },
        {
          path:'signin',component:UserLoginComponent
        },
        {
          path:'signup',component:UserSignupComponent
        },
        {
          path:'myLearnings',component:MylearningsComponent
        },
        { path: 'login', component: UserLoginComponent },
        { path: 'add-user', component: AddUserComponent },
        { path: 'list-user', component: ListUserComponent },
        { path: 'edit-user', component: EditUserComponent },
      ]
    },
    {
      path:'myLearnings',component:MylearningsComponent
    },
    {
          path:'userHome',component:UserHomeComponent,
          children:[
            {
              path:'myLearnings',component:MylearningsComponent
            },
          ]

    },
    
    {
      
      path:'mentorHome',component:MentorHomeComponent
    },
    {
      path:'adminHome',component:AdminHomeComponent
    },
   
 
  { path: 'add-user', component: AddUserComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'edit-user', component: EditUserComponent },
  ];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule { }

/*const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'signin', component: UserLoginComponent },
  { path: 'home', component: HomeComponent},
  { path: 'add-user', component: AddUserComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'edit-user', component: EditUserComponent },
  
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

//export const routing = RouterModule.forRoot(routes);
export class AppRoutingModule { }
*/