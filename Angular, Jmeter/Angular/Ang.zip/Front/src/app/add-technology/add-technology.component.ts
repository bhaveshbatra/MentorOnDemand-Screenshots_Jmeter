import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-technology',
  templateUrl: './add-technology.component.html',
  styleUrls: ['./add-technology.component.css']
})
export class AddTechnologyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
